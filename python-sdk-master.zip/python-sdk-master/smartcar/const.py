API_VERSION = "1.0"
API_URL = "https://api.smartcar.com/v{}".format(API_VERSION)
AUTH_URL = "https://auth.smartcar.com/oauth/token"
CONNECT_URL = "https://connect.smartcar.com"
UNIT_SYSTEM_HEADER = "sc-unit-system"
